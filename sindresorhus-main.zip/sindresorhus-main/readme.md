<div align="center">
	<img src="welcome-header.gif" alt="welcome to my github profile">
	<br>
	<br>
</div>

**i love code**&nbsp;&nbsp;![](cat-typing.gif)&nbsp;&nbsp;**and unicorns**&nbsp;&nbsp;![](unicorn.gif)

<img src="party-furby.gif" align="right" width="60">

<br>

![](under-construction.gif)

<br>

check out my latest app: [Supercharge](https://sindresorhus.com/supercharge) ![](hot.gif)

and my [latest blog post](https://sindresorhus.com/blog) ![](hot.gif)

<br>
<br>

![](counter.gif) ![](badge1.gif) ![](badge2.gif) ![](badge3.png) ![](badge4.gif) ![](badge5.gif) ![](badge6.gif)

![](flames.gif)
